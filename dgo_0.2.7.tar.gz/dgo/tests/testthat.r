library(testthat)
library(dgo)

test_check("dgo")
